package com.hadesloader.poolinjector.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.hadesloader.poolinjector.R
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class TrajectoryOverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlay: TrajectoryView? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(41, notification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (overlay == null) {
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            overlay = TrajectoryView(this)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            windowManager?.addView(overlay, params)
        } else overlay?.invalidate()
        return START_STICKY
    }

    override fun onDestroy() {
        overlay?.let { view -> try { windowManager?.removeView(view) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("hades_overlay", "Hades Overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification = NotificationCompat.Builder(this, "hades_overlay")
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle("Hades Overlay активен")
        .setContentText("Линия прицеливания отображается поверх игры")
        .setOngoing(true)
        .build()

    private class TrajectoryView(context: Context) : View(context) {
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 225, 70); strokeWidth = 4f; style = Paint.Style.STROKE }
        private val tablePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(130, 30, 220, 140); strokeWidth = 2f; style = Paint.Style.STROKE }
        private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 26f; setShadowLayer(4f, 1f, 1f, Color.BLACK) }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val prefs = context.getSharedPreferences("overlay", Context.MODE_PRIVATE)
            val marginX = width * 0.08f
            val top = height * 0.27f
            val bottom = height * 0.73f
            val left = marginX
            val right = width - marginX
            val table = RectF(left, top, right, bottom)
            canvas.drawRoundRect(table, 18f, 18f, tablePaint)
            val x = left + table.width() * prefs.getInt("x", 50) / 100f
            val y = top + table.height() * prefs.getInt("y", 50) / 100f
            val angle = Math.toRadians(prefs.getInt("angle", 0).toDouble())
            val dx = cos(angle).toFloat()
            val dy = sin(angle).toFloat()
            canvas.drawCircle(x, y, 11f, ballPaint)
            drawReflectedPath(canvas, x, y, dx, dy, table)
            canvas.drawText("HADES • ручная калибровка", 24f, height - 34f, textPaint)
        }

        private fun drawReflectedPath(canvas: Canvas, startX: Float, startY: Float, initialDx: Float, initialDy: Float, bounds: RectF) {
            val path = Path().apply { moveTo(startX, startY) }
            var x = startX
            var y = startY
            var dx = initialDx
            var dy = initialDy
            repeat(4) {
                val tx = when {
                    dx > 0.0001f -> (bounds.right - x) / dx
                    dx < -0.0001f -> (bounds.left - x) / dx
                    else -> Float.POSITIVE_INFINITY
                }
                val ty = when {
                    dy > 0.0001f -> (bounds.bottom - y) / dy
                    dy < -0.0001f -> (bounds.top - y) / dy
                    else -> Float.POSITIVE_INFINITY
                }
                val distance = min(if (tx > 0f) tx else Float.POSITIVE_INFINITY, if (ty > 0f) ty else Float.POSITIVE_INFINITY)
                if (!distance.isFinite()) return
                x += dx * distance
                y += dy * distance
                path.lineTo(x, y)
                if (abs(tx - ty) < 0.5f) { dx = -dx; dy = -dy }
                else if (tx < ty) dx = -dx else dy = -dy
            }
            canvas.drawPath(path, linePaint)
        }
    }
}
