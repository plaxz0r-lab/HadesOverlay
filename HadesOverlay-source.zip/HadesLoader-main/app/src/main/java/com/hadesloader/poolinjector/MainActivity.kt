package com.hadesloader.poolinjector

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.hadesloader.poolinjector.service.TrajectoryOverlayService
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("overlay", MODE_PRIVATE) }
    private lateinit var xValue: TextView
    private lateinit var yValue: TextView
    private lateinit var angleValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            setBackgroundColor(0xFF171B20.toInt())
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFFF2F4F7.toInt())
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(label("Hades Overlay", 28f))
        root.addView(label("Ручная линия прицеливания для 8 Ball Pool", 15f))
        root.addView(label("Это экспериментальный оверлей: он не распознаёт шары и не считывает состояние игры. Настраивай положение белого шара и угол вручную."))

        xValue = label("")
        root.addView(xValue)
        root.addView(seek(prefs.getInt("x", 50), 100) { v -> prefs.edit().putInt("x", v).apply(); xValue.text = "Положение шара по X: $v%" })

        yValue = label("")
        root.addView(yValue)
        root.addView(seek(prefs.getInt("y", 50), 100) { v -> prefs.edit().putInt("y", v).apply(); yValue.text = "Положение шара по Y: $v%" })

        angleValue = label("")
        root.addView(angleValue)
        root.addView(seek(prefs.getInt("angle", 0), 359) { v -> prefs.edit().putInt("angle", v).apply(); angleValue.text = "Угол удара: $v°" })

        val start = Button(this).apply {
            text = "Включить линию поверх игры"
            setOnClickListener { startOverlay() }
        }
        root.addView(start, matchWrap())
        root.addView(Button(this).apply {
            text = "Выключить оверлей"
            setOnClickListener { stopService(Intent(this@MainActivity, TrajectoryOverlayService::class.java)); Toast.makeText(this@MainActivity, "Оверлей выключен", Toast.LENGTH_SHORT).show() }
        }, matchWrap())
        root.addView(label("Как пользоваться", 18f))
        root.addView(label("1. Разреши отображение поверх других приложений.\n2. Выставь примерное положение битка внутри стола.\n3. Укажи направление удара ползунком угла.\n4. Включи оверлей и открой игру.\n\nПрозрачный слой не перехватывает касания: по игре можно нажимать. Настройки меняются в этом приложении — после изменения нажми «Включить» ещё раз."))
        setContentView(root)
        xValue.text = "Положение шара по X: ${prefs.getInt("x", 50)}%"
        yValue.text = "Положение шара по Y: ${prefs.getInt("y", 50)}%"
        angleValue.text = "Угол удара: ${prefs.getInt("angle", 0)}°"
    }

    private fun seek(default: Int, max: Int, changed: (Int) -> Unit): SeekBar = SeekBar(this).apply {
        this.max = max
        progress = default
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser) changed(value) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "Разреши показ поверх других приложений, затем вернись и нажми кнопку ещё раз", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, TrajectoryOverlayService::class.java)
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, "Линия включена. Открой 8 Ball Pool", Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
}
