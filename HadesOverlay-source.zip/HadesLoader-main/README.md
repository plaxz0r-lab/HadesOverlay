# Hades Overlay (manual prototype)

This fork replaces the original non-functional APK-copying injector with a small Android overlay prototype.

## What it does
- Requests Android's "Display over other apps" permission.
- Displays a transparent, non-touchable full-screen layer above other apps, so game taps pass through.
- Draws a manually positioned cue-ball marker and a ray that reflects from a manually approximated rectangular table boundary.
- Lets the user adjust cue-ball X/Y position and shot angle in the app.
- Runs as a foreground service with a persistent notification.

## Important limitations
- It does **not** detect balls, pockets, table edges, spin, cue power, or game state automatically.
- It does **not** read game memory, modify the 8 Ball Pool APK, or inject code into the game.
- The displayed line is a geometric guide, not a verified 8 Ball Pool physics prediction. It will need manual calibration and may not match the real table position or game physics.
- This is a prototype, not a finished competitive/cheat tool. Use at your own risk and check the game's rules.

## Build
Open the project in Android Studio with Android SDK 33 installed, then run **Build > Build APK(s)** or:

```bash
./gradlew assembleDebug
```

The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Install and use
1. Install the APK.
2. Open Hades Overlay and allow **Display over other apps**.
3. Set the cue-ball X/Y position and angle.
4. Tap **Включить линию поверх игры**.
5. Open 8 Ball Pool. The overlay is pass-through and does not consume taps.
6. Return to Hades Overlay to adjust the line; tap the start button again to refresh it.
7. Tap **Выключить оверлей** to stop it.

The table frame is currently estimated as 8% screen margin horizontally and 27%-73% screen height. This is a rough default and is not calibrated to every device/game layout.
